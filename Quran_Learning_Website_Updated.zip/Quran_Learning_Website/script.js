
document.addEventListener('DOMContentLoaded', function() {
    // Display a dynamic welcome message or date
    const welcomeMessage = document.createElement('p');
    welcomeMessage.textContent = 'Today's date is: ' + new Date().toLocaleDateString();
    document.querySelector('main').appendChild(welcomeMessage);
});

// Example of a simple dropdown menu for the navigation bar
const navItems = document.querySelectorAll('nav ul li');
navItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        // Assuming dropdown content is within a div with class 'dropdown-content'
        const dropdown = item.querySelector('.dropdown-content');
        if (dropdown) {
            dropdown.style.display = 'block';
        }
    });

    item.addEventListener('mouseleave', () => {
        const dropdown = item.querySelector('.dropdown-content');
        if (dropdown) {
            dropdown.style.display = 'none';
        }
    });
});
